/**
 * Spring Security configuration.
 */
package com.guaire.innapcitas.security;
