/**
 * Spring Data JPA repositories.
 */
package com.guaire.innapcitas.repository;
