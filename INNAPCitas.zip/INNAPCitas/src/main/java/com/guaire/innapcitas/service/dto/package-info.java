/**
 * Data Transfer Objects.
 */
package com.guaire.innapcitas.service.dto;
