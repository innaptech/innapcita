/**
 * Spring MVC REST controllers.
 */
package com.guaire.innapcitas.web.rest;
