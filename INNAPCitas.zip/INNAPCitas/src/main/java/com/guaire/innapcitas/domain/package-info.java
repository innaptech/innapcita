/**
 * JPA domain objects.
 */
package com.guaire.innapcitas.domain;
