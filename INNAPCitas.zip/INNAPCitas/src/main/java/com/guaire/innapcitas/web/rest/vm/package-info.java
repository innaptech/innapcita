/**
 * View Models used by Spring MVC REST controllers.
 */
package com.guaire.innapcitas.web.rest.vm;
