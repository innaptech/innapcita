/**
 * Service layer beans.
 */
package com.guaire.innapcitas.service;
