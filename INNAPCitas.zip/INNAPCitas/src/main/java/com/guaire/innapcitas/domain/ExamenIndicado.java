package com.guaire.innapcitas.domain;

public class ExamenIndicado {

    private String examen;

    private String referencia;

    public String getExamen() {
        return examen;
    }

    public void setExamen(String examen) {
        this.examen = examen;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }
}
