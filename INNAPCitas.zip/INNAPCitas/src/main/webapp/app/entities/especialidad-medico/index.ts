export * from './especialidad-medico.service';
export * from './especialidad-medico-update.component';
export * from './especialidad-medico-delete-dialog.component';
export * from './especialidad-medico-detail.component';
export * from './especialidad-medico.component';
export * from './especialidad-medico-medico.component';
export * from './especialidad-medico.route';
