export * from './especialidad.service';
export * from './especialidad-update.component';
export * from './especialidad-delete-dialog.component';
export * from './especialidad-detail.component';
export * from './especialidad.component';
export * from './especialidad.route';
