export * from './cabecera-informe.service';
export * from './cabecera-informe-update.component';
export * from './cabecera-informe-delete-dialog.component';
export * from './cabecera-informe-detail.component';
export * from './cabecera-informe.component';
export * from './cabecera-informe.route';
