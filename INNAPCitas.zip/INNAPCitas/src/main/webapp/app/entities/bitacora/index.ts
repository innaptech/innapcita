export * from './bitacora.service';
export * from './bitacora-update.component';
export * from './bitacora-delete-dialog.component';
export * from './bitacora-detail.component';
export * from './bitacora.component';
export * from './bitacora.route';
